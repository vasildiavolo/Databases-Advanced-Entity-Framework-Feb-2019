﻿namespace Cinema.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-UK0ERFQ\SQLEXPRESS;Database=Cinema;Integrated Security=True";
    }
}
